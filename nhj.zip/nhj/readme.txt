gpg --batch --passphrase '' --quick-generate-key "test_nhj@kasikornleasing.com" rsa3072 encrypt,sign 0

gpg --output nhj_public64.key --export -a test_nhj@kasikornleasing.com
gpg --export-secret-key -a test_nhj@kasikornleasing.com > nhj_private64.key

